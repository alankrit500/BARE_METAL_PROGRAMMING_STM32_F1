#include "stm32f10x.h"
#include <stdio.h>
#include <stdlib.h>

void SysTickDelayMs(int n);
void SysTickDelay_us(int n);

int main()
{
	RCC->APB2ENR |=(1<<4);     // ENABLE CLOCK FOR PORT C
	GPIOC->CRH|=0x44444444;    // RESET PORT C
	GPIOC->CRH|=0x00200000;    // GPIOC OUTPUT =>  PUSH_PULL  ; PIN : 13
	//	GPIOC->CRH|=(2<<(5*4));  // WORKING :: GROUP -> NUMBER_OF_BITS_USED_FOR_A_SINGLE_PIN
	while(1)
	{
	  GPIOC->ODR = GPIOC->ODR ^ (1<<13);
 	  SysTickDelayMs(1000);
//	SysTickDelay_us(1000);
	}
}

void SysTickDelayMs(int n)
{
	SysTick->CTRL=0x5;                   // ENABLE SYSTICK  [CLOCK SOURCE: AHB ; SYSTICK : ENABLE ]
	SysTick->LOAD=72000-1;               // RELOAD NUMBER OF CYCLES PER MILLISECONDS
//	SysTick->VAL=0;                      // CLEAR CURRENT VALUE REGISTER

	for(int i=0;i<n;i++)
	while(!(SysTick->CTRL & (1<<16)));   // Check flag for systick underflow 
	
		SysTick->CTRL=0;             // Systick Disable for next time or keep systick counting for every millisecond.
}

void SysTickDelay_us(int n)
{
	SysTick->CTRL=0x5;      // ENABLE SYSTICK
	SysTick->LOAD=72-1;     // RELOAD NUMBER OF CYCLES PER MICROSECONDS
//	SysTick->VAL=0;         // CLEAR CURRENT VALUE REGISTER
	
	for(int i=0;i<n;i++)
	{
		while(!(SysTick->CTRL & (1<<16)));
	}
		SysTick->CTRL=0;
}